/**
 * Build script — генерує статичну HTML-сторінку з документацією API
 * у директорію dist/ для публікації на Bolt.
 */

const fs = require("fs");
const path = require("path");

const distDir = path.join(__dirname, "..", "dist");

if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

const html = `<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Менеджер нотатків та категорій — API</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      min-height: 100vh;
      padding: 2rem;
    }
    .container { max-width: 900px; margin: 0 auto; }
    h1 { font-size: 2rem; margin-bottom: 0.5rem; color: #38bdf8; }
    .subtitle { color: #94a3b8; margin-bottom: 2rem; font-size: 1.1rem; }
    .card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 12px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }
    .card h2 { color: #38bdf8; font-size: 1.3rem; margin-bottom: 1rem; }
    .endpoint {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      padding: 0.6rem 0;
      border-bottom: 1px solid #334155;
      font-family: 'Fira Code', monospace;
      font-size: 0.95rem;
    }
    .endpoint:last-child { border-bottom: none; }
    .method {
      padding: 0.25rem 0.6rem;
      border-radius: 6px;
      font-size: 0.8rem;
      font-weight: 700;
      min-width: 60px;
      text-align: center;
    }
    .get { background: #065f46; color: #6ee7b7; }
    .post { background: #1e40af; color: #93c5fd; }
    .put { background: #78350f; color: #fcd34d; }
    .delete { background: #991b1b; color: #fca5a5; }
    .path { color: #cbd5e1; }
    .info { margin-top: 2rem; color: #94a3b8; font-size: 0.9rem; line-height: 1.6; }
    a { color: #38bdf8; text-decoration: none; }
    a:hover { text-decoration: underline; }
    .badge {
      display: inline-block;
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 6px;
      padding: 0.25rem 0.6rem;
      font-size: 0.8rem;
      margin: 0.25rem 0.25rem 0.25rem 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Менеджер нотатків та категорій</h1>
    <p class="subtitle">REST API — Node.js + Express + SQLite (Theme #6)</p>

    <div class="card">
      <h2>Технології</h2>
      <div>
        <span class="badge">Node.js</span>
        <span class="badge">Express.js</span>
        <span class="badge">SQLite (better-sqlite3)</span>
        <span class="badge">CORS</span>
        <span class="badge">Morgan</span>
        <span class="badge">Swagger UI</span>
        <span class="badge">DI Container</span>
      </div>
    </div>

    <div class="card">
      <h2>Користувачі — /api/users</h2>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/users</span> — список усіх користувачів</div>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/users/:id</span> — користувач за ID</div>
      <div class="endpoint"><span class="method post">POST</span><span class="path">/api/users</span> — створити користувача</div>
    </div>

    <div class="card">
      <h2>Категорії — /api/categories</h2>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/categories</span> — список усіх категорій</div>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/categories/user/:userId</span> — категорії користувача</div>
      <div class="endpoint"><span class="method post">POST</span><span class="path">/api/categories</span> — створити категорію</div>
    </div>

    <div class="card">
      <h2>Нотатки — /api/notes</h2>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/notes</span> — список усіх нотатків</div>
      <div class="endpoint"><span class="method get">GET</span><span class="path">/api/notes/:id</span> — нотаток за ID</div>
      <div class="endpoint"><span class="method post">POST</span><span class="path">/api/notes</span> — створити нотаток</div>
      <div class="endpoint"><span class="method put">PUT</span><span class="path">/api/notes/:id</span> — оновити нотаток</div>
      <div class="endpoint"><span class="method delete">DELETE</span><span class="path">/api/notes/:id</span> — видалити нотаток</div>
    </div>

    <div class="info">
      <p><strong>Swagger документація:</strong> доступна за адресою <code>/api-docs</code> на запущеному сервері.</p>
      <p><strong>Архітектура:</strong> Маршрути &rarr; Контролери &rarr; Сервіси &rarr; Репозиторії з DI-контейнером.</p>
      <p><strong>Запуск локально:</strong> <code>npm start</code> — сервер запускається на порту 3000.</p>
    </div>
  </div>
</body>
</html>`;

fs.writeFileSync(path.join(distDir, "index.html"), html);

console.log("Build completed: dist/index.html generated");
