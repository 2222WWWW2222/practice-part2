/**
 * Контролер нотатків — обробка HTTP-запитів для /api/notes.
 */

class NoteController {
  constructor(noteService) {
    this.noteService = noteService;
  }

  getAllNotes(req, res, next) {
    try {
      const notes = this.noteService.getAllNotes();
      res.json(notes);
    } catch (err) {
      next(err);
    }
  }

  getNoteById(req, res, next) {
    try {
      const note = this.noteService.getNoteById(Number(req.params.id));
      res.json(note);
    } catch (err) {
      next(err);
    }
  }

  createNote(req, res, next) {
    try {
      const note = this.noteService.createNote(req.body);
      res.status(201).json(note);
    } catch (err) {
      next(err);
    }
  }

  updateNote(req, res, next) {
    try {
      const note = this.noteService.updateNote(Number(req.params.id), req.body);
      res.json(note);
    } catch (err) {
      next(err);
    }
  }

  deleteNote(req, res, next) {
    try {
      const result = this.noteService.deleteNote(Number(req.params.id));
      res.json(result);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = NoteController;
