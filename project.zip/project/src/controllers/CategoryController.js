/**
 * Контролер категорій — обробка HTTP-запитів для /api/categories.
 */

class CategoryController {
  constructor(categoryService) {
    this.categoryService = categoryService;
  }

  getAllCategories(req, res, next) {
    try {
      const categories = this.categoryService.getAllCategories();
      res.json(categories);
    } catch (err) {
      next(err);
    }
  }

  getCategoriesByUser(req, res, next) {
    try {
      const categories = this.categoryService.getCategoriesByUser(Number(req.params.userId));
      res.json(categories);
    } catch (err) {
      next(err);
    }
  }

  createCategory(req, res, next) {
    try {
      const category = this.categoryService.createCategory(req.body);
      res.status(201).json(category);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = CategoryController;
