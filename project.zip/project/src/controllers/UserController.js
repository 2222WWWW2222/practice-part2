/**
 * Контролер користувачів — обробка HTTP-запитів для /api/users.
 */

class UserController {
  constructor(userService) {
    this.userService = userService;
  }

  getAllUsers(req, res, next) {
    try {
      const users = this.userService.getAllUsers();
      res.json(users);
    } catch (err) {
      next(err);
    }
  }

  getUserById(req, res, next) {
    try {
      const user = this.userService.getUserById(Number(req.params.id));
      res.json(user);
    } catch (err) {
      next(err);
    }
  }

  createUser(req, res, next) {
    try {
      const user = this.userService.createUser(req.body);
      res.status(201).json(user);
    } catch (err) {
      next(err);
    }
  }
}

module.exports = UserController;
