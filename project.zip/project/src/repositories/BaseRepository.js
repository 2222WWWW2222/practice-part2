/**
 * Базовий клас репозиторію зі спільними допоміжними методами.
 */

class BaseRepository {
  /**
   * @param {import("better-sqlite3").Database} db
   * @param {string} tableName
   */
  constructor(db, tableName) {
    this.db = db;
    this.tableName = tableName;
  }

  _rowToObj(row) {
    return row ? { ...row } : null;
  }
}

module.exports = BaseRepository;
