/**
 * Репозиторій нотатків — шар доступу до даних таблиці notes.
 */

const BaseRepository = require("./BaseRepository");

class NoteRepository extends BaseRepository {
  constructor(db) {
    super(db, "notes");
  }

  findAll() {
    const rows = this.db
      .prepare(
        `SELECT n.id, n.title, n.content, n.user_id, n.category_id, n.created_at,
                u.name  AS user_name,
                c.name  AS category_name
         FROM notes n
         LEFT JOIN users u      ON n.user_id     = u.id
         LEFT JOIN categories c ON n.category_id = c.id
         ORDER BY n.id`
      )
      .all();
    return rows.map((r) => this._rowToObj(r));
  }

  findById(id) {
    const row = this.db
      .prepare(
        `SELECT n.id, n.title, n.content, n.user_id, n.category_id, n.created_at,
                u.name  AS user_name,
                c.name  AS category_name
         FROM notes n
         LEFT JOIN users u      ON n.user_id     = u.id
         LEFT JOIN categories c ON n.category_id = c.id
         WHERE n.id = ?`
      )
      .get(id);
    return this._rowToObj(row);
  }

  create({ title, content, user_id, category_id }) {
    const result = this.db
      .prepare(
        "INSERT INTO notes (title, content, user_id, category_id) VALUES (?, ?, ?, ?)"
      )
      .run(title, content ?? "", user_id, category_id ?? null);
    return this.findById(result.lastInsertRowid);
  }

  update(id, { title, content, category_id }) {
    const existing = this.findById(id);
    if (!existing) return null;

    this.db
      .prepare(
        `UPDATE notes
         SET title       = COALESCE(?, title),
             content     = COALESCE(?, content),
             category_id = COALESCE(?, category_id)
         WHERE id = ?`
      )
      .run(
        title       ?? null,
        content     ?? null,
        category_id !== undefined ? (category_id ?? null) : null,
        id
      );

    return this.findById(id);
  }

  delete(id) {
    const result = this.db.prepare("DELETE FROM notes WHERE id = ?").run(id);
    return result.changes > 0;
  }
}

module.exports = NoteRepository;
