/**
 * Репозиторій категорій — шар доступу до даних таблиці categories.
 */

const BaseRepository = require("./BaseRepository");

class CategoryRepository extends BaseRepository {
  constructor(db) {
    super(db, "categories");
  }

  findAll() {
    const rows = this.db
      .prepare(
        `SELECT c.id, c.name, c.user_id, u.name AS user_name
         FROM categories c
         LEFT JOIN users u ON c.user_id = u.id
         ORDER BY c.id`
      )
      .all();
    return rows.map((r) => this._rowToObj(r));
  }

  findAllByUserId(userId) {
    const rows = this.db
      .prepare("SELECT id, name, user_id FROM categories WHERE user_id = ? ORDER BY id")
      .all(userId);
    return rows.map((r) => this._rowToObj(r));
  }

  findById(id) {
    const row = this.db
      .prepare(
        `SELECT c.id, c.name, c.user_id, u.name AS user_name
         FROM categories c
         LEFT JOIN users u ON c.user_id = u.id
         WHERE c.id = ?`
      )
      .get(id);
    return this._rowToObj(row);
  }

  create({ name, user_id }) {
    const result = this.db
      .prepare("INSERT INTO categories (name, user_id) VALUES (?, ?)")
      .run(name, user_id);
    return this.findById(result.lastInsertRowid);
  }
}

module.exports = CategoryRepository;
