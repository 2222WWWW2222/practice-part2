/**
 * Репозиторій користувачів — шар доступу до даних таблиці users.
 */

const BaseRepository = require("./BaseRepository");

class UserRepository extends BaseRepository {
  constructor(db) {
    super(db, "users");
  }

  findAll() {
    const rows = this.db.prepare("SELECT id, name, email FROM users ORDER BY id").all();
    return rows.map((r) => this._rowToObj(r));
  }

  findById(id) {
    const row = this.db
      .prepare("SELECT id, name, email FROM users WHERE id = ?")
      .get(id);
    return this._rowToObj(row);
  }

  findByEmail(email) {
    const row = this.db
      .prepare("SELECT id, name, email FROM users WHERE email = ?")
      .get(email);
    return this._rowToObj(row);
  }

  create({ name, email }) {
    const result = this.db
      .prepare("INSERT INTO users (name, email) VALUES (?, ?)")
      .run(name, email);
    return this.findById(result.lastInsertRowid);
  }
}

module.exports = UserRepository;
