/**
 * Конфігурація бази даних SQLite.
 * Створення таблиць та заповнення початковими даними (seed).
 */

const fs = require("fs");
const path = require("path");

function ensureDataDir() {
  const dataDir = path.join(__dirname, "..", "..", "data");
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

/**
 * Ініціалізація схеми бази даних.
 * @param {import("better-sqlite3").Database} db
 */
function initDatabase(db) {
  ensureDataDir();

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id    INTEGER PRIMARY KEY AUTOINCREMENT,
      name  TEXT    NOT NULL,
      email TEXT    NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS categories (
      id      INTEGER PRIMARY KEY AUTOINCREMENT,
      name    TEXT    NOT NULL,
      user_id INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS notes (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      title       TEXT    NOT NULL,
      content     TEXT    NOT NULL DEFAULT '',
      user_id     INTEGER NOT NULL,
      category_id INTEGER,
      created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id)     REFERENCES users(id)     ON DELETE CASCADE,
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
    );

    CREATE INDEX IF NOT EXISTS idx_categories_user   ON categories(user_id);
    CREATE INDEX IF NOT EXISTS idx_notes_user        ON notes(user_id);
    CREATE INDEX IF NOT EXISTS idx_notes_category    ON notes(category_id);
  `);
}

/**
 * Заповнення таблиць демонстраційними даними (тільки якщо таблиці порожні).
 * @param {import("better-sqlite3").Database} db
 */
function seedDatabase(db) {
  const userCount = db.prepare("SELECT COUNT(*) as cnt FROM users").get();
  if (userCount.cnt > 0) return;

  const insertUser = db.prepare("INSERT INTO users (name, email) VALUES (?, ?)");
  const insertCategory = db.prepare("INSERT INTO categories (name, user_id) VALUES (?, ?)");
  const insertNote = db.prepare(
    "INSERT INTO notes (title, content, user_id, category_id) VALUES (?, ?, ?, ?)"
  );

  const tx = db.transaction(() => {
    // Користувачі
    insertUser.run("Олена Коваленко", "olena@example.com");
    insertUser.run("Андрій Шевченко", "andriy@example.com");
    insertUser.run("Марія Бондаренко", "maria@example.com");

    // Категорії
    insertCategory.run("Робота", 1);
    insertCategory.run("Навчання", 1);
    insertCategory.run("Особисте", 2);
    insertCategory.run("Проєкти", 3);

    // Нотатки
    insertNote.run("План на тиждень", "Завершити звіт та підготувати презентацію", 1, 1);
    insertNote.run("Курсова робота", "Написати розділ про архітектуру додатка", 1, 2);
    insertNote.run("Список покупок", "Молоко, хліб, кава, фрукти", 2, 3);
    insertNote.run("Ідеї для проєкту", "Додати DI-контейнер та Swagger документацію", 3, 4);
    insertNote.run("Без категорії", "Цей нотаток не прив'язаний до жодної категорії", 2, null);
  });

  tx();
}

module.exports = { initDatabase, seedDatabase, ensureDataDir };
