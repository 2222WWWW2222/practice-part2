/**
 * OpenAPI / Swagger специфікація.
 * Опис кожного маршруту знаходиться у відповідних файлах routes/* через JSDoc-коментарі.
 * Тут визначені спільні компоненти: схеми та стандартні відповіді.
 */

const swaggerJsdoc = require("swagger-jsdoc");

const swaggerDefinition = {
  openapi: "3.0.0",
  info: {
    title: "Менеджер нотатків та категорій",
    version: "1.0.0",
    description:
      "REST API для управління нотатками та категоріями. " +
      "Тема #6 — Коледжне практичне завдання.\n\n" +
      "**Технології:** Node.js, Express, SQLite (better-sqlite3), Swagger.\n\n" +
      "**Архітектура:** Маршрути → Контролери → Сервіси → Репозиторії з DI-контейнером.",
    contact: {
      name: "Коледжне практичне завдання",
    },
  },
  servers: [
    {
      url: "http://localhost:3000",
      description: "Локальний сервер розробки",
    },
  ],
  tags: [
    { name: "Користувачі", description: "Операції з користувачами" },
    { name: "Категорії", description: "Операції з категоріями" },
    { name: "Нотатки", description: "Операції з нотатками" },
  ],
  components: {
    schemas: {
      User: {
        type: "object",
        properties: {
          id: { type: "integer", example: 1 },
          name: { type: "string", example: "Олена Коваленко" },
          email: { type: "string", format: "email", example: "olena@example.com" },
        },
      },
      Category: {
        type: "object",
        properties: {
          id: { type: "integer", example: 1 },
          name: { type: "string", example: "Робота" },
          user_id: { type: "integer", example: 1 },
          user_name: { type: "string", example: "Олена Коваленко", nullable: true },
        },
      },
      Note: {
        type: "object",
        properties: {
          id: { type: "integer", example: 1 },
          title: { type: "string", example: "План на тиждень" },
          content: { type: "string", example: "Завершити звіт" },
          user_id: { type: "integer", example: 1 },
          category_id: { type: "integer", example: 1, nullable: true },
          created_at: { type: "string", format: "date-time", example: "2026-10-06T12:00:00Z" },
          user_name: { type: "string", example: "Олена Коваленко", nullable: true },
          category_name: { type: "string", example: "Робота", nullable: true },
        },
      },
    },
    responses: {
      BadRequest: {
        description: "Невірний запит — відсутні або некоректні дані",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                error: { type: "string", example: "Ім'я користувача є обов'язковим" },
                status: { type: "integer", example: 400 },
              },
            },
          },
        },
      },
      NotFound: {
        description: "Ресурс не знайдено",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                error: { type: "string", example: "Нотаток не знайдено" },
                status: { type: "integer", example: 404 },
              },
            },
          },
        },
      },
      InternalServerError: {
        description: "Внутрішня помилка сервера",
        content: {
          "application/json": {
            schema: {
              type: "object",
              properties: {
                error: { type: "string", example: "Внутрішня помилка сервера" },
                status: { type: "integer", example: 500 },
              },
            },
          },
        },
      },
    },
  },
};

const options = {
  definition: swaggerDefinition,
  apis: [__dirname + "/../routes/*.js"],
};

const spec = swaggerJsdoc(options);

module.exports = spec;
