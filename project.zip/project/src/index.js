/**
 * Точка входу додатка.
 * Запускає Express-сервер на порту 3000.
 */

const { createApp } = require("./app");

const PORT = process.env.PORT || 3000;

const app = createApp();

const server = app.listen(PORT, () => {
  console.log("═══════════════════════════════════════════");
  console.log("  Менеджер нотатків та категорій");
  console.log("═══════════════════════════════════════════");
  console.log(`  Сервер запущено:  http://localhost:${PORT}`);
  console.log(`  Swagger UI:       http://localhost:${PORT}/api-docs`);
  console.log(`  API база:         http://localhost:${PORT}/api`);
  console.log("═══════════════════════════════════════════");
});

module.exports = { server, app };
