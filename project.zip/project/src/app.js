/**
 * Конфігурація Express-додатка.
 * Збирає всі middleware, маршрути та обробники помилок.
 */

const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const swaggerUi = require("swagger-ui-express");

const { DIContainer, registerDependencies } = require("./container/DIContainer");
const { notFoundHandler, errorHandler } = require("./middleware/errorHandler");
const swaggerSpec = require("./config/swagger");

function createApp() {
  const app = express();

  // --- Ініціалізація DI-контейнера ---
  const container = new DIContainer();
  registerDependencies(container);
  app.locals.container = container;

  // --- Глобальні middleware ---
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan("dev"));

  // --- Swagger UI ---
  app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
    customTitle: "Менеджер нотатків та категорій — API документація",
    customCss: ".swagger-ui .topbar { background-color: #1a1a2e; }",
  }));

  // --- Базовий маршрут ---
  app.get("/", (_req, res) => {
    res.json({
      name: "Менеджер нотатків та категорій",
      version: "1.0.0",
      docs: "/api-docs",
      endpoints: {
        users: "/api/users",
        categories: "/api/categories",
        notes: "/api/notes",
      },
    });
  });

  // --- API маршрути ---
  app.use("/api/users", container.resolve("userRoutes"));
  app.use("/api/categories", container.resolve("categoryRoutes"));
  app.use("/api/notes", container.resolve("noteRoutes"));

  // --- Обробка помилок ---
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = { createApp };
