/**
 * Маршрути для категорій — /api/categories
 */

const express = require("express");

const router = express.Router();

/**
 * @swagger
 * /api/categories:
 *   get:
 *     summary: Отримати список усіх категорій
 *     description: Повертає масив усіх категорій із бази даних (із іменами власників).
 *     tags: [Категорії]
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Category'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.get("/", (req, res, next) => {
  req.app.locals.container.resolve("categoryController").getAllCategories(req, res, next);
});

/**
 * @swagger
 * /api/categories/user/{userId}:
 *   get:
 *     summary: Отримати категорії конкретного користувача
 *     tags: [Категорії]
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: integer
 *         description: Ідентифікатор користувача
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Category'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.get("/user/:userId", (req, res, next) => {
  req.app.locals.container.resolve("categoryController").getCategoriesByUser(req, res, next);
});

/**
 * @swagger
 * /api/categories:
 *   post:
 *     summary: Створити нову категорію
 *     tags: [Категорії]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, user_id]
 *             properties:
 *               name:
 *                 type: string
 *                 description: Назва категорії
 *                 example: "Робота"
 *               user_id:
 *                 type: integer
 *                 description: ID користувача-власника
 *                 example: 1
 *     responses:
 *       201:
 *         description: Категорію створено
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Category'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.post("/", (req, res, next) => {
  req.app.locals.container.resolve("categoryController").createCategory(req, res, next);
});

module.exports = router;
