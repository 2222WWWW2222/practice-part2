/**
 * Маршрути для нотатків — /api/notes
 */

const express = require("express");

const router = express.Router();

/**
 * @swagger
 * /api/notes:
 *   get:
 *     summary: Отримати список усіх нотатків
 *     description: Повертає масив усіх нотатків (із іменами авторів та категорій).
 *     tags: [Нотатки]
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Note'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.get("/", (req, res, next) => {
  req.app.locals.container.resolve("noteController").getAllNotes(req, res, next);
});

/**
 * @swagger
 * /api/notes/{id}:
 *   get:
 *     summary: Отримати нотаток за ID
 *     tags: [Нотатки]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Ідентифікатор нотатка
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Note'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.get("/:id", (req, res, next) => {
  req.app.locals.container.resolve("noteController").getNoteById(req, res, next);
});

/**
 * @swagger
 * /api/notes:
 *   post:
 *     summary: Створити новий нотаток
 *     tags: [Нотатки]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [title, user_id]
 *             properties:
 *               title:
 *                 type: string
 *                 description: Заголовок нотатка
 *                 example: "План на тиждень"
 *               content:
 *                 type: string
 *                 description: Текст нотатка
 *                 example: "Завершити звіт та підготувати презентацію"
 *               user_id:
 *                 type: integer
 *                 description: ID автора
 *                 example: 1
 *               category_id:
 *                 type: integer
 *                 nullable: true
 *                 description: ID категорії (необов'язково)
 *                 example: 1
 *     responses:
 *       201:
 *         description: Нотаток створено
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Note'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.post("/", (req, res, next) => {
  req.app.locals.container.resolve("noteController").createNote(req, res, next);
});

/**
 * @swagger
 * /api/notes/{id}:
 *   put:
 *     summary: Оновити нотаток
 *     tags: [Нотатки]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Ідентифікатор нотатка
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *                 example: "Оновлений заголовок"
 *               content:
 *                 type: string
 *                 example: "Оновлений текст нотатка"
 *               category_id:
 *                 type: integer
 *                 nullable: true
 *                 example: 2
 *     responses:
 *       200:
 *         description: Нотаток оновлено
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Note'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.put("/:id", (req, res, next) => {
  req.app.locals.container.resolve("noteController").updateNote(req, res, next);
});

/**
 * @swagger
 * /api/notes/{id}:
 *   delete:
 *     summary: Видалити нотаток
 *     tags: [Нотатки]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Ідентифікатор нотатка
 *     responses:
 *       200:
 *         description: Нотаток видалено
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: integer
 *                   example: 1
 *                 message:
 *                   type: string
 *                   example: "Нотаток успішно видалено"
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.delete("/:id", (req, res, next) => {
  req.app.locals.container.resolve("noteController").deleteNote(req, res, next);
});

module.exports = router;
