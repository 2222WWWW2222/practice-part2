/**
 * Маршрути для користувачів — /api/users
 * Опис OpenAPI включено у swagger-специфікацію (src/config/swagger.js).
 */

const express = require("express");

const router = express.Router();

/**
 * @swagger
 * /api/users:
 *   get:
 *     summary: Отримати список усіх користувачів
 *     description: Повертає масив усіх користувачів із бази даних.
 *     tags: [Користувачі]
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/User'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
router.get("/", (req, res, next) => {
  req.app.locals.container.resolve("userController").getAllUsers(req, res, next);
});

/**
 * @swagger
 * /api/users/{id}:
 *   get:
 *     summary: Отримати користувача за ID
 *     tags: [Користувачі]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: Ідентифікатор користувача
 *     responses:
 *       200:
 *         description: Успішна відповідь
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 */
router.get("/:id", (req, res, next) => {
  req.app.locals.container.resolve("userController").getUserById(req, res, next);
});

/**
 * @swagger
 * /api/users:
 *   post:
 *     summary: Створити нового користувача
 *     tags: [Користувачі]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, email]
 *             properties:
 *               name:
 *                 type: string
 *                 description: Ім'я користувача
 *                 example: "Олена Коваленко"
 *               email:
 *                 type: string
 *                 format: email
 *                 description: Email користувача (унікальний)
 *                 example: "olena@example.com"
 *     responses:
 *       201:
 *         description: Користувача створено
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       409:
 *         description: Користувач з такою адресою вже існує
 */
router.post("/", (req, res, next) => {
  req.app.locals.container.resolve("userController").createUser(req, res, next);
});

module.exports = router;
