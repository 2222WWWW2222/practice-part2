/**
 * Сервіс користувачів — бізнес-логіка для роботи з користувачами.
 */

class UserService {
  constructor(userRepository) {
    this.userRepository = userRepository;
  }

  getAllUsers() {
    return this.userRepository.findAll();
  }

  getUserById(id) {
    const user = this.userRepository.findById(id);
    if (!user) {
      const err = new Error("Користувача не знайдено");
      err.status = 404;
      throw err;
    }
    return user;
  }

  createUser({ name, email }) {
    if (!name || !name.trim()) {
      const err = new Error("Ім'я користувача є обов'язковим");
      err.status = 400;
      throw err;
    }
    if (!email || !email.trim()) {
      const err = new Error("Email є обов'язковим");
      err.status = 400;
      throw err;
    }

    const existing = this.userRepository.findByEmail(email);
    if (existing) {
      const err = new Error("Користувач з такою адресою вже існує");
      err.status = 409;
      throw err;
    }

    return this.userRepository.create({ name: name.trim(), email: email.trim() });
  }
}

module.exports = UserService;
