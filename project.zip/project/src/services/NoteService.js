/**
 * Сервіс нотатків — бізнес-логіка для роботи з нотатками.
 */

class NoteService {
  constructor(noteRepository, categoryRepository, userRepository) {
    this.noteRepository = noteRepository;
    this.categoryRepository = categoryRepository;
    this.userRepository = userRepository;
  }

  getAllNotes() {
    return this.noteRepository.findAll();
  }

  getNoteById(id) {
    const note = this.noteRepository.findById(id);
    if (!note) {
      const err = new Error("Нотаток не знайдено");
      err.status = 404;
      throw err;
    }
    return note;
  }

  createNote({ title, content, user_id, category_id }) {
    if (!title || !title.trim()) {
      const err = new Error("Заголовок нотатка є обов'язковим");
      err.status = 400;
      throw err;
    }
    if (!user_id) {
      const err = new Error("user_id є обов'язковим");
      err.status = 400;
      throw err;
    }

    const user = this.userRepository.findById(user_id);
    if (!user) {
      const err = new Error("Користувача не знайдено");
      err.status = 404;
      throw err;
    }

    if (category_id) {
      const category = this.categoryRepository.findById(category_id);
      if (!category) {
        const err = new Error("Категорію не знайдено");
        err.status = 404;
        throw err;
      }
    }

    return this.noteRepository.create({
      title: title.trim(),
      content: content ?? "",
      user_id,
      category_id: category_id ?? null,
    });
  }

  updateNote(id, { title, content, category_id }) {
    const note = this.noteRepository.findById(id);
    if (!note) {
      const err = new Error("Нотаток не знайдено");
      err.status = 404;
      throw err;
    }

    if (category_id !== undefined && category_id !== null) {
      const category = this.categoryRepository.findById(category_id);
      if (!category) {
        const err = new Error("Категорію не знайдено");
        err.status = 404;
        throw err;
      }
    }

    return this.noteRepository.update(id, { title, content, category_id });
  }

  deleteNote(id) {
    const deleted = this.noteRepository.delete(id);
    if (!deleted) {
      const err = new Error("Нотаток не знайдено");
      err.status = 404;
      throw err;
    }
    return { id, message: "Нотаток успішно видалено" };
  }
}

module.exports = NoteService;
