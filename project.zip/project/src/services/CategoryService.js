/**
 * Сервіс категорій — бізнес-логіка для роботи з категоріями.
 */

class CategoryService {
  constructor(categoryRepository, userRepository) {
    this.categoryRepository = categoryRepository;
    this.userRepository = userRepository;
  }

  getAllCategories() {
    return this.categoryRepository.findAll();
  }

  getCategoriesByUser(userId) {
    this.userRepository.findById(userId);
    return this.categoryRepository.findAllByUserId(userId);
  }

  createCategory({ name, user_id }) {
    if (!name || !name.trim()) {
      const err = new Error("Назва категорії є обов'язковою");
      err.status = 400;
      throw err;
    }
    if (!user_id) {
      const err = new Error("user_id є обов'язковим");
      err.status = 400;
      throw err;
    }

    const user = this.userRepository.findById(user_id);
    if (!user) {
      const err = new Error("Користувача не знайдено");
      err.status = 404;
      throw err;
    }

    return this.categoryRepository.create({ name: name.trim(), user_id });
  }
}

module.exports = CategoryService;
