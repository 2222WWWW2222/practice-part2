/**
 * Контейнер впровадження залежностей (DI Container)
 * Реалізує патерн "Service Locator" для централізованого управління залежностями.
 */

const Database = require("better-sqlite3");
const path = require("path");

// Репозиторії
const UserRepository = require("../repositories/UserRepository");
const CategoryRepository = require("../repositories/CategoryRepository");
const NoteRepository = require("../repositories/NoteRepository");

// Сервіси
const UserService = require("../services/UserService");
const CategoryService = require("../services/CategoryService");
const NoteService = require("../services/NoteService");

// Контролери
const UserController = require("../controllers/UserController");
const CategoryController = require("../controllers/CategoryController");
const NoteController = require("../controllers/NoteController");

// Маршрути
const userRoutes = require("../routes/userRoutes");
const categoryRoutes = require("../routes/categoryRoutes");
const noteRoutes = require("../routes/noteRoutes");

// Конфігурація бази даних
const { initDatabase, seedDatabase } = require("../config/database");

class DIContainer {
  constructor() {
    this._registry = new Map();
    this._singletons = new Map();
  }

  register(name, factory, { singleton = false } = {}) {
    this._registry.set(name, { factory, singleton });
  }

  resolve(name) {
    const registration = this._registry.get(name);
    if (!registration) {
      throw new Error(`Залежність "${name}" не зареєстрована в контейнері`);
    }

    if (registration.singleton) {
      if (this._singletons.has(name)) {
        return this._singletons.get(name);
      }
      const instance = registration.factory(this);
      this._singletons.set(name, instance);
      return instance;
    }

    return registration.factory(this);
  }
}

/**
 * Реєстрація усіх залежностей у контейнері.
 * @param {DIContainer} container
 */
function registerDependencies(container) {
  // --- Інфраструктура ---
  container.register(
    "db",
    () => {
      const { ensureDataDir } = require("../config/database");
      ensureDataDir();
      const db = new Database(path.join(__dirname, "..", "..", "data", "app.db"));
      db.pragma("journal_mode = WAL");
      db.pragma("foreign_keys = ON");
      initDatabase(db);
      seedDatabase(db);
      return db;
    },
    { singleton: true }
  );

  // --- Репозиторії ---
  container.register("userRepository", (c) => new UserRepository(c.resolve("db")));
  container.register("categoryRepository", (c) => new CategoryRepository(c.resolve("db")));
  container.register("noteRepository", (c) => new NoteRepository(c.resolve("db")));

  // --- Сервіси ---
  container.register("userService", (c) => new UserService(c.resolve("userRepository")));
  container.register("categoryService", (c) => new CategoryService(c.resolve("categoryRepository"), c.resolve("userRepository")));
  container.register("noteService", (c) => new NoteService(c.resolve("noteRepository"), c.resolve("categoryRepository"), c.resolve("userRepository")));

  // --- Контролери ---
  container.register("userController", (c) => new UserController(c.resolve("userService")));
  container.register("categoryController", (c) => new CategoryController(c.resolve("categoryService")));
  container.register("noteController", (c) => new NoteController(c.resolve("noteService")));

  // --- Маршрути ---
  container.register("userRoutes", () => userRoutes);
  container.register("categoryRoutes", () => categoryRoutes);
  container.register("noteRoutes", () => noteRoutes);
}

module.exports = { DIContainer, registerDependencies };
