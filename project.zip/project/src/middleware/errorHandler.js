/**
 * Централізована обробка помилок.
 * Перехоплює всі помилки, що передані через next(err),
 * і повертає структуровану JSON-відповідь.
 */

function notFoundHandler(req, res, _next) {
  res.status(404).json({
    error: "Маршрут не знайдено",
    path: req.originalUrl,
    method: req.method,
  });
}

function errorHandler(err, _req, res, _next) {
  const status = err.status || 500;
  const message = err.message || "Внутрішня помилка сервера";

  if (status >= 500) {
    console.error(`[Помилка ${status}] ${message}`, err.stack || err);
  } else {
    console.warn(`[Помилка ${status}] ${message}`);
  }

  res.status(status).json({
    error: message,
    status,
  });
}

module.exports = { notFoundHandler, errorHandler };
